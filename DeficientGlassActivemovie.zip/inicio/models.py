from django.db import models
import requests

# Create your models here.
class Product(models.Model):
  namearticle = models.CharField(max_length=128)
  price = models.IntegerField()
  ofertprice = models.IntegerField(blank=True, default=0)
  image = models.ImageField(upload_to='images', null=True)
  amount = models.IntegerField()
  description = models.CharField(max_length=256)
  categorias = models.CharField(max_length = 128)
  Actualizacion_Automatica = models.BooleanField()
  def valor(precio):
    ans = ""
    for i in range(0, len(precio)-4):
      ans += precio[i]
    return float(ans)
  dolar = valor(requests.get("https://www.dolarsi.com/api/api.php?type=valoresprincipales").json()[1]['casa']['compra'])
  