
def cart_total_amount(request):
  total = 0.0
  for key, value in request.session['cart'].items():
    total = total + (float(value['price'])) * value['quantity']
  return {'cart_total_amount':total} 