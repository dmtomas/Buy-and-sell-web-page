from django.urls import path
from . import views
from .views import *
from django.conf import settings
from django.conf.urls.static import static




urlpatterns = [
    path('', views.index, name='index'),

    path('tienda', views.tienda, name='tienda'),

    path("productos/id=<int:Product_id>", views.article, name="articulos"),

    path("carrito", views.carrito, name="carrito"),

    path("Quienes_Somos", views.Quienes_Somos, name="Quienes_Somos"),

    path("contactos", views.contactos, name="contactos"),

    path('add_product/id=<int:Product_id>', add_product, name='add_product'),

    path('increment_product/id=<int:Product_id>', increment_product, name='increment_product'),

    path('remove_product/id=<int:Product_id>', remove_product, name='remove_product'),

    path('decrement_product/id=<int:Product_id>', decrement_product, name='decrement_product'),
    
    path('clear/', clear_cart, name='clear_cart'),
    path('update', views.actualizarprecios, name="update")

]

if settings.DEBUG:
  urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
  urlpatterns += static(settings.STATIC_URL, documen_root= settings.STATIC_ROOT)