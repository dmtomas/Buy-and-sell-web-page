from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Product
from .cart import Cart
from celery import Celery
from celery.schedules import crontab
from time import sleep
import requests

app = Celery(backend='db+sqlite:///db.sqlite3')

def index(request):
  obj = Product.objects.all()
  cart = Cart(request)
  context = {
      "productos": obj
  }
  return render(request, "inicio.html", context)

def tienda(request):
  obj = Product.objects.all()
  cart = Cart(request)
  context = {
    "productos": obj,
  }
  return render(request, "tienda.html", context)


def article(request, Product_id):
  cart = Cart(request)
  obj = Product.objects.get(id=Product_id)
  context = {
     "productos": obj
    }
  return render(request, "arti.html", context)

def carrito(request):
  obj = Product.objects.all()
  cart = Cart(request)
  context = {
    
    "productos": obj
  }
  return render(request, "carrito.html", context)

def Quienes_Somos(request):
  cart = Cart(request)
  context = {

  }
  return render(request, "Quienes_Somos.html", context)

def contactos(request):
  cart = Cart(request)
  context = {

  }
  return render(request, "contactos.html", context)

#Todo a partir de acá está lo del carrito
#Al terminar la función sobre el producto, te redireccionan a la tienda
def add_product(request, Product_id):
  cart = Cart(request)
  product = Product.objects.get(id=Product_id)
  cart.add(product=product)
  return redirect('tienda')

def increment_product(request, Product_id):
  cart = Cart(request)
  product = Product.objects.get(id=Product_id)
  cart.add(product=product)
  return redirect('carrito')

def remove_product(request, Product_id):
  cart = Cart(request)
  product = Product.objects.get(id=Product_id)
  cart.remove(product)
  return redirect('carrito')

def decrement_product(request, Product_id):
  cart = Cart(request)
  product = Product.objects.get(id=Product_id)
  cart.decrement(product=product)
  return redirect('carrito')

def clear_cart(request):
  cart = Cart(request)
  cart.clear()
  return redirect('carrito')



#Está funcion busca el cuanto cambió el dolar en la ultima hora y actualiza los precios segun esto.
#Se que es una solución horrible, pero el programa me lo esta devolviendo como un string y usa el simbolo "," entonces no me lo deja pasar a float de una :P

@app.task
def actualizarprecios(request):
  res = requests.get("https://www.dolarsi.com/api/api.php?type=valoresprincipales")
  obj = Product.objects.all()
  data = res.json()
  dolar = data[1]['casa']['venta']
  ans = ""
  for i in range(0, len(dolar)-4):
    ans += dolar[i]
  if float(ans) > obj.dolar: 
    for productos in obj:
      if productos.Actualizacion_Automatica == True:
        productos.price *= (float(ans) / productos.dolar)
        productos.dolar = float(ans)
        productos.save()
  return redirect('index')


#Esto todavia no funciona pero es lo que va a correr la aplicación cada 1h

@app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(10.0, actualizarprecios, name='add every 10')




